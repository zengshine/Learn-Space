﻿namespace ODataSamples.CustomFormatService
{
    partial class BusinessCard
    {
        public string Title { get; set; }
    }
}
