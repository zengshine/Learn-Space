﻿namespace ODataSamples.WebApiService.Helper
{
    public static class Utility
    {
        public const int DefaultPageSize = 8;
    }
}