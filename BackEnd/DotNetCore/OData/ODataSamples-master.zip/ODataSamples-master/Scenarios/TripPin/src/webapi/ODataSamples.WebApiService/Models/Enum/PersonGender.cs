﻿namespace ODataSamples.WebApiService.Models
{
    public enum PersonGender
    {
        Male = 0,
        Female = 1,
        Unknown = 2,
    }
}