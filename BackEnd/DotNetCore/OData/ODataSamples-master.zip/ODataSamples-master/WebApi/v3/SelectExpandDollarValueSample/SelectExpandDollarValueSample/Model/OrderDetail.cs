﻿
namespace SelectExpandDollarValueSample.Model
{
    public class OrderDetail
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Ammount { get; set; }
        public decimal Price { get; set; }
    }
}
