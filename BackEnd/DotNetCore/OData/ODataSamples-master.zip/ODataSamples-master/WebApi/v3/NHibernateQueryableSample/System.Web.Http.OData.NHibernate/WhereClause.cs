﻿
namespace System.Web.Http.OData.NHibernate
{
    public class WhereClause
    {
        public string Clause { get; set; }

        public object[] PositionalParameters { get; set; }
    }
}
