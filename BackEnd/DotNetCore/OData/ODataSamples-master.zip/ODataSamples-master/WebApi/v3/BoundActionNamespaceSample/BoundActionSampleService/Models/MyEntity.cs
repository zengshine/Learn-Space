﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BoundActionSample.Models
{
    public class MyEntity
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
    }
}