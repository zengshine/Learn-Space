﻿
namespace ODataEFBatchSample.Models
{
    public class OrderLine
    {
        public virtual int Id { get; set; }
        public virtual int OrderId { get; set; }
    }
}
