﻿namespace DynamicEdmModelCreation
{
    public static class Constants
    {
        public const string CustomODataPath = "CustomODataPath";

        public const string ODataDataSource = "ODataDataSource";

        public const string MyDataSource = "mydatasource";

        public const string AnotherDataSource = "anotherdatasource";
    }
}