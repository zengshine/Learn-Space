﻿
namespace System.Web.OData.NHibernate
{
    public class WhereClause
    {
        public string Clause { get; set; }

        public object[] PositionalParameters { get; set; }
    }
}
