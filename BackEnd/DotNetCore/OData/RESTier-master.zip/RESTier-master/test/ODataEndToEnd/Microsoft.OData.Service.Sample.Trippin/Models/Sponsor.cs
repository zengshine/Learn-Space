﻿namespace Microsoft.OData.Service.Sample.Trippin.Models
{
    public class Sponsor
    {
        public int SponsorId { get; set; }

        public string Name { get; set; }
    }
}