﻿namespace Microsoft.OData.Service.Sample.Trippin.Models
{
    public class GlodSponsor : Sponsor
    {
        public int Funding { get; set; }
    }
}